#!/usr/bin/env python
import sys
import numpy as np
import pyvista as pv
import argparse
import trame
# Define the argument parser
parser = argparse.ArgumentParser(description="pyvista pkl files from tornadobox")

# Positional arguments 
parser.add_argument("dr", help="path to directory with npy files")
parser.add_argument("t1",type=int, help="start time")
parser.add_argument("t2",type=int, nargs='?', default=0 , help="end time")

#parser.add_argument("pngdir", nargs='?', default='',help="path to directory for pngs")
#parser.add_argument("field", nargs='?', default="pp" , help="field to plot")

# Optional arguments
parser.add_argument("-o", dest="outdr", type=str, default="pngs", help="out directory for pngs")
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-vb", dest="verbose", action="store_true",  help="print more stuff")
parser.add_argument("-lg", dest="legend", action="store_true",  help="show legend")
parser.add_argument("-d", dest="show_domain", action="store_true",  help="plot domain box")
parser.add_argument("-p", dest="iso_p", action="store_true",  help="plot p isosurfaces")
parser.add_argument("-u", dest="iso_u", action="store_true",  help="plot u isosurfaces")
parser.add_argument("-v", dest="iso_v", action="store_true",  help="plot v isosurfaces")
parser.add_argument("-w", dest="iso_w", action="store_true",  help="plot w isosurfaces")
parser.add_argument("-c", dest="iso_c", action="store_true",  help="plot c isosurfaces")
#parser.add_argument("-cl", dest="close", type=float, default=1., help="camera distance, try 1 and .2")
parser.add_argument("-ch", dest="camerah", type=float, default=5., help="camera height")
parser.add_argument("-z", dest="zaim", type=float, default=.4, help="camera aim at z")
a=parser.parse_args()

pv.global_theme.allow_empty_mesh = True

times=[]
for i in range(a.t1,max(a.t2+1,a.t1+1)):
    tf="{:06}".format(i)
    times.append(tf)
if a.verbose: print(times)



for time in times:

    # Load input directory and time step
    dr = a.dr 

    # Load scalar fields
    u = np.load(dr+'/'+'u'+time+'.npy')
    v = np.load(dr+'/'+'v'+time+'.npy')
    w = np.load(dr+'/'+'w'+time+'.npy')
    p = np.load(dr+'/'+'p'+time+'.npy')
    c = np.load(dr+'/'+'c'+time+'.npy')


    up = .5*(u[:,:,1:]+u[:,:,:-1])
    vp = .5*(v[:,1:,:]+v[:,:-1,:])
    wp = .5*(w[1:]+w[:-1])
    s = np.sqrt(up*up+vp*vp+wp*wp)
    dx = 4./p.shape[2]
    dy=dx
    print('dx=',dx)
    uatv=0.*v
    uatv[:,1:-1,:] = .25*( u[:,:-1,:-1] + u[:,:-1,1:] + u[:,1:,:-1] + u[:,1:,1:] )
    uatv[:,0,:] = .25*( u[:,-1,:-1] + u[:,-1,1:] + u[:,0,:-1] + u[:,0,1:] )
    uatv[:,-1,:] = uatv[:,0,:]
    vatu=0.*u
    vatu[:,:,1:-1] = .25*( v[:,:-1,:-1] + v[:,:-1,1:] + v[:,1:,:-1] + v[:,1:,1:] )
    vatu[:,:,0] = .25*( v[:,:-1,-1] + v[:,:-1,0] + v[:,1:,-1] + v[:,1:,0] )
    vatu[:,:,-1] = vatu[:,:,0]
    zeta = -(uatv[:,1:,:]-uatv[:,:-1,:])/dy + (vatu[:,:,1:]-vatu[:,:,:-1])/dx

    # Print shapes and ranges
    if a.verbose:
        print(time)
        print('u', u.shape, u.max(), u.min())
        print('v', v.shape, v.max(), v.min())
        print('w', w.shape, w.max(), w.min())
        print('p', p.shape, p.max(), p.min())
        print('c', c.shape, c.max(), c.min())
        print('s', s.shape, s.max(), s.min())
        print('zeta', zeta.shape, zeta.max(), zeta.min())



    # --- Fix Orientation Issues ---

    # Create grid for 'w' (staggered in y and z)
    nz, ny, nx = w.shape  # Get correct grid dimensions
    gridw = pv.ImageData()
    gridw.dimensions = (nx, ny, nz)  # Swap to (X, Y, Z)
    gridw.origin = (dx / 2, dx / 2,0)
    gridw.spacing = (dx, dx, dx)
    gridw.point_data["w"] = np.transpose(w, (2, 1, 0)).flatten(order="F")  # Swap axes

    # Create grid for 'p' (staggered in x, y, and z)
    nz, ny, nx = p.shape  # Get correct grid dimensions
    gridp = pv.ImageData()
    gridp.dimensions = (nx, ny, nz)
    gridp.origin = (dx / 2, dx / 2, dx / 2)
    gridp.spacing = (dx, dx, dx)
    gridp.point_data["p"] = np.transpose(p, (2, 1, 0)).flatten(order="F")
    gridp.point_data["s"] = np.transpose(s, (2, 1, 0)).flatten(order="F")
    gridp.point_data["c"] = np.transpose(c, (2, 1, 0)).flatten(order="F")
    gridp.point_data["zeta"] = np.transpose(zeta, (2, 1, 0)).flatten(order="F")

    # Generate isosurfaces for 'w'
    contours_w_neg = gridw.contour([-0.5],scalars='w')
    contours_w_pos = gridw.contour([0.5],scalars='w')

    # Generate isosurfaces for 'p'
    contours_p1 = gridp.contour([-2],scalars='p')
    contours_p2 = gridp.contour([-3],scalars='p')
    contours_p3 = gridp.contour([1.5],scalars='s')
    contours_p4 = gridp.contour([6],scalars='c')
    contours_p5 = gridp.contour([-40],scalars='zeta')

    # --- Extract a 2D slice at z=0 (XY plane) --- not used
    slice_plane = gridp.slice(normal=[0, 0, 1], origin=(0, 0,dx ))  # Plane at z=0
    contour_levels = [s.min() + i * (s.max() - s.min()) / 10 for i in range(1, 10)]
    contour_2d = slice_plane.contour(contour_levels, scalars='s')

    # Create a small sphere at the origin (0,0,0)
    origin_marker = pv.Sphere(radius=0.03, center=(0, 0, 0))

    # Bounding box for the domain
    bbox = pv.Cube(bounds=(0, 4, 0, 4, 0, 1))
    edges = bbox.extract_all_edges()

    # --- Visualization ---
    if not a.show:
        plotter = pv.Plotter(off_screen=True)
    else:
        plotter = pv.Plotter()
#    plotter.add_mesh(contours_w_neg, color="lightblue", opacity=0.5, label="w = -0.5")
#    plotter.add_mesh(contours_w_pos, color="green", opacity=0.5, label="w = 0.5")
    plotter.add_mesh(contours_p1, color="green", opacity=0.5, label="p = -2")
#    plotter.add_mesh(contours_p2, color="purple", opacity=1.0, label="p = -3")
#    plotter.add_mesh(contours_p3, color="yellow", opacity=.5, label="s =  2")
#    plotter.add_mesh(contours_p4, color="red", opacity=.5, label="c =  6")
    plotter.add_mesh(contours_p5, color="purple", opacity=.5, label="$\zeta$ =  -40")
    plotter.add_mesh(edges, color='black', line_width=3, label="Domain Boundaries")
    plotter.add_mesh(origin_marker, color="yellow", label="Origin Marker")
    plotter.add_text(time,color='pink')
#    plotter.add_mesh(contour_2d, cmap="coolwarm", opacity=0.8, label="2D Contour (p at z=0)")
    plotter.add_mesh(slice_plane, scalars="s", cmap="OrRd", opacity=1.0, clim=[0,3.0 ])
    
    
    


    # Set custom camera position
    plotter.camera_position = [
        (2, -6,a.camerah ),
        (2, 2, 0),
        (0, 0, 1)
    ]


    if a.legend: plotter.add_legend()
    if a.show:
#        plotter.export_vtksz("scene.vtksz")
#        plotter.export_gltf("scene.gltf")  
#        plotter.export_vrml("scene.vrml")  
        plotter.export_html('scene.html') # the best
        plotter.show()
        
        
    else:
        oupn = a.outdr+'/'+time+'.png'
        plotter.show(screenshot=oupn)
        print("output to ",oupn)





