#!/usr/bin/env python
import sys
import numpy as np
import argparse
import matplotlib.pyplot as plt
# Define the argument parser
parser = argparse.ArgumentParser(description="pyvista pkl files from tornadobox")

# Positional arguments 
parser.add_argument("dr", help="path to directory with npy files")
parser.add_argument("t1",type=int, help="start time")
parser.add_argument("t2",type=int, nargs='?', default=0 , help="end time")

#parser.add_argument("pngdir", nargs='?', default='',help="path to directory for pngs")
#parser.add_argument("field", nargs='?', default="pp" , help="field to plot")

# Optional arguments
parser.add_argument("-o", dest="outdr", type=str, default="pngs", help="out directory for pngs")
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-vb", dest="verbose", action="store_true",  help="print more stuff")
parser.add_argument("-lg", dest="legend", action="store_true",  help="show legend")
parser.add_argument("-d", dest="show_domain", action="store_true",  help="plot domain box")
parser.add_argument("-p", dest="iso_p", action="store_true",  help="plot p isosurfaces")
parser.add_argument("-u", dest="iso_u", action="store_true",  help="plot u isosurfaces")
parser.add_argument("-v", dest="iso_v", action="store_true",  help="plot v isosurfaces")
parser.add_argument("-w", dest="iso_w", action="store_true",  help="plot w isosurfaces")
parser.add_argument("-c", dest="iso_c", action="store_true",  help="plot c isosurfaces")
#parser.add_argument("-cl", dest="close", type=float, default=1., help="camera distance, try 1 and .2")
parser.add_argument("-ch", dest="camerah", type=float, default=5., help="camera height")
parser.add_argument("-z", dest="zaim", type=float, default=.4, help="camera aim at z")
a=parser.parse_args()

times=[]
for i in range(a.t1,max(a.t2+1,a.t1+1)):
    tf="{:06}".format(i)
    times.append(tf)
if a.verbose: print(times)



for time in times:

    # Load input directory and time step
    dr = a.dr 

    # Load scalar fields
    u = np.load(dr+'/'+'u'+time+'.npy')
    v = np.load(dr+'/'+'v'+time+'.npy')
    w = np.load(dr+'/'+'w'+time+'.npy')
    p = np.load(dr+'/'+'p'+time+'.npy')
    c = np.load(dr+'/'+'c'+time+'.npy')


    up = .5*(u[:,:,1:]+u[:,:,:-1])
    vp = .5*(v[:,1:,:]+v[:,:-1,:])
    wp = .5*(w[1:]+w[:-1])
    s = np.sqrt(up*up+vp*vp+wp*wp)
    Nz,Ny,Nx=p.shape
    dx = 4./Nx
    dy = dx

    uatv=0.*v
    uatv[:,1:-1,:] = .25*( u[:,:-1,:-1] + u[:,:-1,1:] + u[:,1:,:-1] + u[:,1:,1:] )
    uatv[:,0,:] = .25*( u[:,-1,:-1] + u[:,-1,1:] + u[:,0,:-1] + u[:,0,1:] )
    uatv[:,-1,:] = uatv[:,0,:]
    vatu=0.*u
    vatu[:,:,1:-1] = .25*( v[:,:-1,:-1] + v[:,:-1,1:] + v[:,1:,:-1] + v[:,1:,1:] )
    vatu[:,:,0] = .25*( v[:,:-1,-1] + v[:,:-1,0] + v[:,1:,-1] + v[:,1:,0] )
    vatu[:,:,-1] = vatu[:,:,0]
    zeta = -(uatv[:,1:,:]-uatv[:,:-1,:])/dy + (vatu[:,:,1:]-vatu[:,:,:-1])/dx

    # Print shapes and ranges
    if a.verbose:
        print(time)
        print('u', u.shape, u.max(), u.min())
        print('v', v.shape, v.max(), v.min())
        print('w', w.shape, w.max(), w.min())
        print('p', p.shape, p.max(), p.min())
        print('c', c.shape, c.max(), c.min())
        print('s', s.shape, s.max(), s.min())
        print('zeta', zeta.shape, zeta.max(), zeta.min())


    x,y=np.meshgrid(np.linspace(dx/2,4-dx/2,Nx),np.linspace(dx/2,4-dx/2,Nx))

    zzmin=zeta[0].min()
    zzmax=zeta[0].max()
    zztext= "{0:5.2f} < $\zeta$ < {1:5.2f}".format(zzmin,zzmax)
    print(zztext)

    more,this=plt.subplots(figsize=[10,10])
    levs=np.arange(-2.5,2.51,.2)
#    print(levs)
#    print(w[Nz//4].max(),w[Nz//4].min())
    cf=this.contourf(x,y,w[Nz//4],cmap='bwr',levels=levs)
    cf=this.contour(x,y,zeta[0],levels=np.arange(-205,206,10),colors=['k'])
#    this.quiver(xp[ kh, ::vd,::vd], yp[kh,::vd,::vd], U[kh,::vd,::vd], V[kh,::vd,::vd],
#        scale=1.0*Nx/vd,units='width',zorder=3,color='black')
    this.set_aspect(1.)
    tf = "{:5.2f}".format(int(time)/10)
    more.text(-.1,1.01,tf,color='black',fontsize=36,transform = this.transAxes)
    more.text(.4,1.02,zztext,color='black',fontsize=24,transform = this.transAxes)
    cf.cmap.set_under('blue')
    cf.cmap.set_over('red')
#    more.colorbar(cf)

    if a.show:
        plt.show()
    else:
        oupn=a.outdr+'/'+time+'.png'
        print(oupn)
        plt.savefig(oupn)
    plt.close()

