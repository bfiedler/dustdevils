#!/usr/bin/env python
# 18 March 2025
from PIL import Image , ImageDraw ,  ImageFont
import os, sys, argparse

parser = argparse.ArgumentParser(description=" make a title PNG for png2mp4.py ")
#parser.add_argument("inpng", help="text added to this PNG")
# Optional arguments
parser.add_argument("-o", dest="outpng", type=str, default="title.png", help="out PNG file name")
# Version argument
parser.add_argument("--version", action="version", version="0.1")
args = parser.parse_args()

# Open an Image
#img = Image.open(args.inpng)
img = Image.new(mode="RGB", size=(1000, 1000),color='white')

# Call draw Method to add 2D graphics in an image
I1 = ImageDraw.Draw(img)

# Custom font style and font size
myFont = ImageFont.truetype('FreeMono.ttf', 48)

# Add Text to an image, Edit as needed.
I1.text((10, 60), "R4096g0w4", font=myFont, fill =(0, 0, 0))
I1.text((10, 120), u"128 \u00D7 128 \u00D7 32", font=myFont, fill =(0, 0, 0))
I1.text((10, 180 ), u"\u03B6 vertical vorticity at z=1/64 ", font=myFont, fill =(0, 0, 0))
I1.text((10, 240), "w at z=1/4", font=myFont, fill =(0, 0, 0))
#I1.text((10, 240), "p: -4 -2 -1 -.5 ", font=myFont, fill =(0,255, 0))
#I1.text((10, 300), "w: -.2 ", font=myFont, fill =(0,200,255 ))

# Display edited image
img.show()

# Save the edited image
permit='y'
check = os.path.exists(args.outpng)
if check:
    permit= input(args.outpng+' exists, overwrite? (y/n)')
if permit=='y':
    img.save(args.outpng)
    print(" image saved in ",args.outpng) 
