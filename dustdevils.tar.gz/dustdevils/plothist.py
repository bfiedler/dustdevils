#!/usr/bin/env python
# 18 March 2025
import argparse
import pandas as pd
import math
import sys
#import matplotlib
#matplotlib.use('Agg')
import matplotlib.pyplot as plt
SMALL_SIZE = 18
MEDIUM_SIZE = 24
BIGGER_SIZE = 36

plt.rc('font', size=SMALL_SIZE)          # controls default text sizes
plt.rc('axes', titlesize=SMALL_SIZE)     # fontsize of the axes title
plt.rc('axes', labelsize=MEDIUM_SIZE)    # fontsize of the x and y labels
plt.rc('xtick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
plt.rc('ytick', labelsize=SMALL_SIZE)    # fontsize of the tick labels
plt.rc('legend', fontsize=SMALL_SIZE)    # legend fontsize
plt.rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title


# Define the argument parser
parser = argparse.ArgumentParser(description="plots history file from tornadobox")

# Positional arguments (like npyfile1 and optional npyfile2)
parser.add_argument("histfile", help="path to history file")
parser.add_argument("histfile2", nargs='?', default="", help="path to history file")

# Optional arguments
parser.add_argument("-o", dest="oufn", type=str, default="", help="out image file name")
parser.add_argument("-t", dest="title", type=str, default="", help="plot title")
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-ymax", dest="ymax", type=float, default=4, help="max on y axis")
parser.add_argument("-tmax", dest="tmax", type=float, help="max on t axis")
parser.add_argument("-stime", dest="stime", type=float, default=None, help="mark special time")

# Version argument
parser.add_argument("--version", action="version", version="0.1")

# Parse arguments
args = parser.parse_args()
plt.rcParams["figure.figsize"] = (10,10)

df = pd.read_csv(args.histfile,sep="\s+")
print(type(df))
print(df.columns)
print(df['time'])
plt.plot(df['time'],df['pmin0'],label='$p_{min}$')
plt.plot(df['time'],df['smax0'],label='$s_{max}$')
#plt.plot(df['time'],df['pmin'],label='p')
#plt.plot(df['time'],df['smax'],label='s')
plt.plot(df['time'],df['zetamax0'],label='$\zeta_{max}$')
plt.plot(df['time'],df['zetamin0'],label='$\zeta_{min}$')

############### finish labels #########################

plt.legend()
plt.grid()
#plt.ylim([0,args.ymax])
#if args.tmax: plt.xlim([0,args.tmax])

if not args.title:
    title=args.histfile.split('/')[-1]
    title=title.replace('.hist','')
    if args.histfile2:
        title2=args.histfile2.split('/')[-1]
        title2=title2.replace('.hist','')
        title += '  '+title2
    print(title)
    args.title=title
plt.title(args.title)
plt.xlabel('t')

if not args.oufn:
    args.oufn = args.histfile.replace('.hist','.png')

plt.savefig(args.oufn)
print('saved file ',args.oufn)

if args.show: plt.show()
plt.close()

