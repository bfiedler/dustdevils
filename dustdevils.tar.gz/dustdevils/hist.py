#!/usr/bin/env python
import numpy as np
import argparse
# Define the argument parser
parser = argparse.ArgumentParser(description="pyvista pkl files from tornadobox")

# Positional arguments 
parser.add_argument("dr", help="path to directory with npy files")
parser.add_argument("t1",type=int, help="start time")
parser.add_argument("t2",type=int, nargs='?', default=0 , help="end time")

# Optional arguments
parser.add_argument("-s", dest="show", action="store_true",  help="show plot")
parser.add_argument("-vb", dest="verbose", action="store_true",  help="print more stuff")
a=parser.parse_args()

times=[]
for i in range(a.t1,max(a.t2+1,a.t1+1)):
    tf="{:06}".format(i)
    times.append(tf)
if a.verbose: print(times)

print(' time pmin0 smax0 zetamax0 zetamin0 pmin smax')
for time in times:

    # Load input directory and time step
    dr = a.dr 

    # Load scalar fields
    u = np.load(dr+'/'+'u'+time+'.npy')
    v = np.load(dr+'/'+'v'+time+'.npy')
    w = np.load(dr+'/'+'w'+time+'.npy')
    p = np.load(dr+'/'+'p'+time+'.npy')
    c = np.load(dr+'/'+'c'+time+'.npy')


    up = .5*(u[:,:,1:]+u[:,:,:-1])
    vp = .5*(v[:,1:,:]+v[:,:-1,:])
    wp = .5*(w[1:]+w[:-1])
    s = np.sqrt(up*up+vp*vp+wp*wp)

    dx = 4./p.shape[2]
    dy = dx

    uatv=0.*v
    uatv[:,1:-1,:] = .25*( u[:,:-1,:-1] + u[:,:-1,1:] + u[:,1:,:-1] + u[:,1:,1:] )
    uatv[:,0,:] = .25*( u[:,-1,:-1] + u[:,-1,1:] + u[:,0,:-1] + u[:,0,1:] )
    uatv[:,-1,:] = uatv[:,0,:]
    vatu=0.*u
    vatu[:,:,1:-1] = .25*( v[:,:-1,:-1] + v[:,:-1,1:] + v[:,1:,:-1] + v[:,1:,1:] )
    vatu[:,:,0] = .25*( v[:,:-1,-1] + v[:,:-1,0] + v[:,1:,-1] + v[:,1:,0] )
    vatu[:,:,-1] = vatu[:,:,0]
    zeta = -(uatv[:,1:,:]-uatv[:,:-1,:])/dy + (vatu[:,:,1:]-vatu[:,:,:-1])/dx

    # Print shapes and ranges
    if a.verbose:
        print(time)
        print('u', u.shape, u.max(), u.min())
        print('v', v.shape, v.max(), v.min())
        print('w', w.shape, w.max(), w.min())
        print('p', p.shape, p.max(), p.min())
        print('c', c.shape, c.max(), c.min())
        print('s', s.shape, s.max(), s.min())
        print('zeta', zeta.shape, zeta.max(), zeta.min())

    n4="{:10.4f} {:10.4f} {:10.4f} {:10.4f} {:10.4f} {:10.4f}   ".format(p[0].min(),s[0].max(),zeta[0].max(),zeta[0].min(),p.min(),s.max())
    print(int(time)/10.,n4)



